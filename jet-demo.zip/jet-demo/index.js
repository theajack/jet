
Jet.router.use({
  history:false,
  index:'/',
  trueBase:false,
  router:{
    '/':'/intro',
    '/about':'/about',
    '/donate':'/donate'
  }
});
      