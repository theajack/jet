
Jet.router.use({
  history:false,
  index:'/',
  router:{
    '/':'/intro',
    '/about':'/about',
    '/donate':'/donate'
  }
});
      