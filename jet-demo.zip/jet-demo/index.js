new Jet({
  beforemount:function(){
    Jet.$import('@bg',function(mod){
    })
  },
  static:{
    boxHeight:555
  },
  data:{
    pTop:function(){
      return ($J.height()-this.$data.boxHeight)/2
    }
  },
  func:{
    
  }
})
      